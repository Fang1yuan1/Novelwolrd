"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { READER_PALETTES, type ReaderTheme } from "@/lib/reader-theme";
import { splitChapterParagraphs } from "@/lib/chapter-text";
import MobileReaderSettingsSheet from "./MobileReaderSettingsSheet";
import { useCopyProtection } from "@/lib/useCopyProtection";

const STORAGE_KEY = "novelwolrd-reader-prefs";
// مستويات الخط بالجوال: 15 خطوة (14→28) زي مؤشر النقاط بالمرجع. ننقل قيمة الخط القديمة (5 مستويات) تلقائيًا،
// ونخزّن المستوى بمفتاح مستقل (fontLevel) عشان ما نخرّب fontIdx اللي يقرأه القارئ الغني بنفس التخزين.
const OLD_FONT_SIZES = [16, 18, 20, 22, 24];
const FONT_MIN = 14;
const FONT_LEVELS = Array.from({ length: 15 }, (_, i) => FONT_MIN + i);

type Prefs = { theme: ReaderTheme; fontIdx: number; fontLevel: number; brightness: number };

function readSavedPrefs(): Prefs {
  const fallback: Prefs = {
    theme: "original",
    fontIdx: 1,
    fontLevel: 4,
    brightness: 100,
  };
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return fallback;
    const saved = JSON.parse(raw);
    const fontIdx = typeof saved.fontIdx === "number" ? saved.fontIdx : fallback.fontIdx;
    const fromOld = (OLD_FONT_SIZES[fontIdx] ?? OLD_FONT_SIZES[1]) - FONT_MIN;
    return {
      theme: saved.theme && saved.theme in READER_PALETTES ? saved.theme : fallback.theme,
      fontIdx,
      fontLevel:
        typeof saved.fontLevel === "number"
          ? Math.min(FONT_LEVELS.length - 1, Math.max(0, saved.fontLevel))
          : fromOld,
      brightness: typeof saved.brightness === "number" ? saved.brightness : fallback.brightness,
    };
  } catch {
    return fallback;
  }
}

type NovelData = { id: number; title: string; chapter_count?: number };
type ChapterData = {
  chapter_number: number;
  title: string | null;
  content: string;
};

function IconBack() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M15 5l-7 7 7 7" />
    </svg>
  );
}
function IconHeadphones() {
  return (
    <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 14v-2a8 8 0 0 1 16 0v2" />
      <rect x="2.5" y="14" width="5" height="7" rx="2" />
      <rect x="16.5" y="14" width="5" height="7" rx="2" />
    </svg>
  );
}
function IconDots() {
  return (
    <svg width="19" height="19" viewBox="0 0 24 24" fill="currentColor" stroke="none">
      <circle cx="5" cy="12" r="1.6" />
      <circle cx="12" cy="12" r="1.6" />
      <circle cx="19" cy="12" r="1.6" />
    </svg>
  );
}
function IconArrowLeft() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M19 12H5" />
      <path d="M11 6l-6 6 6 6" />
    </svg>
  );
}
function IconArrowRight() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 12h14" />
      <path d="M13 6l6 6-6 6" />
    </svg>
  );
}

export default function MobileChapterReader({
  novel,
  chapter,
  prevNumber,
  nextNumber,
}: {
  novel: NovelData;
  chapter: ChapterData;
  prevNumber: number | null;
  nextNumber: number | null;
}) {
  const [prefs, setPrefs] = useState(readSavedPrefs);
  const { theme, fontLevel, brightness } = prefs;
  // تغيير حجم الخط زي المرجع بالضبط (مقاس من فيديو المرجع بمعدل 60 إطار/ثانية):
  //  ١) المؤشر (النقاط) يتحدّث لحظيًا مع الضغط.  ٢) بعد ~0.22 ثانية من آخر ضغطة يختفي النص كله «والعنوان معه» خلال 0.135 ثانية (خطي، بدون تسارع)
  //  ٣) يتبدّل الحجم وهو مختفي تمامًا (شفافية 0) ويبقى 0.19 ثانية  ٤) يظهر بالحجم الجديد خلال 0.13 ثانية (خطي).
  // ملاحظة من الفيديو: تلاشي شفافية فقط — بدون ضبابية ولا تكبير.
  const [wantLevel, setWantLevel] = useState(fontLevel);
  const [textHidden, setTextHidden] = useState(false);
  const wantRef = useRef(fontLevel);
  const appliedRef = useRef(fontLevel);
  const busyRef = useRef(false);
  const timersRef = useRef<number[]>([]);
  useEffect(() => {
    const timers = timersRef;
    return () => timers.current.forEach((t) => window.clearTimeout(t));
  }, []);
  // عدّاد يعيد تشغيل حركة التلاشي الضبابي كل ما يتغير الثيم فعلًا (اسمين متناوبين بدل إعادة بناء النص)
  const [swap, setSwap] = useState(0);
  const setTheme = (t: ReaderTheme) => {
    if (t === prefs.theme) return;
    setSwap((n) => n + 1);
    setPrefs((prev) => ({ ...prev, theme: t }));
  };
  const later = (fn: () => void, ms: number) => {
    const id = window.setTimeout(fn, ms);
    timersRef.current.push(id);
    return id;
  };
  const runFontCycle = () => {
    if (busyRef.current || wantRef.current === appliedRef.current) return;
    busyRef.current = true;
    setTextHidden(true); // يخفت للصفر
    later(() => {
      appliedRef.current = wantRef.current;
      setPrefs((prev) => ({ ...prev, fontLevel: appliedRef.current })); // تبديل الحجم والنص مختفي
      later(() => {
        setTextHidden(false); // يظهر بالحجم الجديد
        later(() => {
          busyRef.current = false;
          runFontCycle(); // لو صار ضغط أثناء الدورة نكمل للقيمة الأخيرة
        }, 130);
      }, 190);
    }, 135);
  };
  const debounceRef = useRef<number | null>(null);
  const setFontLevel = (fn: (i: number) => number) => {
    const next = fn(wantRef.current);
    if (next === wantRef.current) return;
    wantRef.current = next;
    setWantLevel(next); // المؤشر لحظيًا
    if (debounceRef.current) window.clearTimeout(debounceRef.current);
    debounceRef.current = later(runFontCycle, 220);
  };
  const textFade = {
    opacity: textHidden ? 0 : 1,
    transition: `opacity ${textHidden ? 135 : 130}ms linear`,
  } as const;
  const setBrightness = (n: number) => setPrefs((prev) => ({ ...prev, brightness: n }));
  const [showSheet, setShowSheet] = useState(false);
  const [mounted, setMounted] = useState(false);
  const contentRef = useCopyProtection<HTMLDivElement>();

  useEffect(() => {
    setMounted(true);
  }, []);

  // مزامنة الثيم مع الإعدادات المحفوظة عند رجوع الصفحة من ذاكرة المتصفح (سجل التصفح/زرار رجوع)،
  // عشان مايحصلش تعارض: خلفية الصفحة تفضل بيضاء بينما لوحة الثيمات لسه فاتحة على إنها داكنة
  useEffect(() => {
    const syncFromStorage = () => setPrefs(readSavedPrefs());
    window.addEventListener("pageshow", syncFromStorage);
    document.addEventListener("visibilitychange", syncFromStorage);
    return () => {
      window.removeEventListener("pageshow", syncFromStorage);
      document.removeEventListener("visibilitychange", syncFromStorage);
    };
  }, []);

  useEffect(() => {
    if (!mounted) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs));
    } catch {}
  }, [prefs, mounted]);

  const p = READER_PALETTES[theme];

  // يخلي خلفية الصفحة (html/body) ولون شريط الحالة يطابقوا لون ثيم القراءة الحالي —
  // عشان ما يبانش أبيض عند الفرملة/التمرير الزايد فوق أو تحت المحتوى، ولا بأعلى الشاشة.
  useEffect(() => {
    const html = document.documentElement;
    const prevHtmlBg = html.style.backgroundColor;
    const prevBodyBg = document.body.style.backgroundColor;

    html.style.backgroundColor = p.pageBg;
    document.body.style.backgroundColor = p.pageBg;

    let meta = document.querySelector('meta[name="theme-color"]');
    const prevMetaContent = meta?.getAttribute("content") ?? null;
    if (!meta) {
      meta = document.createElement("meta");
      meta.setAttribute("name", "theme-color");
      document.head.appendChild(meta);
    }
    meta.setAttribute("content", p.pageBg);

    return () => {
      html.style.backgroundColor = prevHtmlBg;
      document.body.style.backgroundColor = prevBodyBg;
      if (meta && prevMetaContent !== null) {
        meta.setAttribute("content", prevMetaContent);
      }
    };
  }, [p.pageBg]);

  const fontSize = FONT_LEVELS[fontLevel];
  const paragraphs = splitChapterParagraphs(chapter.content);

  const chapterLabel = `الفصل ${chapter.chapter_number}${chapter.title ? ` ${chapter.title}` : ""}`;

  return (
    <div
      className="relative min-h-screen"
      style={{
        backgroundColor: p.pageBg,
        color: p.text,
        transition: "background-color 0.4s ease, color 0.4s ease",
      }}
    >
      {/* شريط علوي — رقم واسم الفصل */}
      <header
        className="sticky top-0 z-20 flex items-center gap-3 border-b px-3 py-2.5"
        style={{ backgroundColor: p.pageBg, borderColor: p.divider }}
      >
        <Link href={`/novel/${novel.id}`} aria-label="رجوع" className="shrink-0">
          <IconBack />
        </Link>
        <span className="line-clamp-1 min-w-0 flex-1 text-[13px] font-bold" style={textFade}>
          {chapterLabel}
        </span>
        <span className="shrink-0 opacity-40" title="استماع صوتي — قريبًا" aria-hidden="true">
          <IconHeadphones />
        </span>
        <button
          type="button"
          onClick={() => setShowSheet(true)}
          aria-label="الثيمات والإعدادات"
          className="shrink-0"
        >
          <IconDots />
        </button>
      </header>

      {/* عنوان الفصل — خط عمودي واحد متصل يمتد على السطرين معًا (كالمرجع بدقة) */}
      <div
        className="flex items-stretch gap-3 px-4 pt-6"
        style={textFade}
        onClick={() => {
          if (window.getSelection()?.toString()) return;
          setShowSheet(true);
        }}
      >
        <span
          className="w-[3px] shrink-0 self-stretch rounded-full"
          style={{ backgroundColor: p.chipActiveText }}
        />
        <div>
          <div className="text-[15px] font-bold" style={{ color: p.text }}>
            الفصل {chapter.chapter_number}
          </div>
          {chapter.title && (
            <h1
              className="mt-1 font-bold leading-snug"
              style={{ fontSize: fontSize + 9 }}
            >
              {chapter.title}
            </h1>
          )}
        </div>
      </div>

      {/* النص — الضغط في أي مكان بالفصل يفتح لوحة الثيمات والإعدادات */}
      <div
        ref={contentRef}
        className={`chapter-no-copy px-4 pb-16 pt-6 text-center ${swap === 0 ? "" : `nw-swap-${swap % 2}`}`}
        style={{
          fontSize,
          fontWeight: p.boldText ? 700 : 400,
          ...textFade,
        }}
        onClick={() => {
          if (window.getSelection()?.toString()) return;
          setShowSheet(true);
        }}
      >
        {paragraphs.map((para, i) => (
          <p key={i} className="mb-4 leading-loose">
            {para}
          </p>
        ))}
      </div>

      {/* تنقل بسيط أسفل النص — سهمين وعدّاد الفصل الحالي/الإجمالي (بترتيب LTR ثابت زي المرجع بالضبط) */}
      <div className="flex items-center gap-3 px-5 py-5" dir="ltr">
        {prevNumber !== null ? (
          <Link
            href={`/novel/${novel.id}/chapter/${prevNumber}`}
            aria-label="السابق"
            className="shrink-0"
            style={{ color: p.mutedText }}
          >
            <IconArrowLeft />
          </Link>
        ) : (
          <span aria-hidden="true" className="shrink-0" style={{ color: p.mutedText, opacity: 0.35 }}>
            <IconArrowLeft />
          </span>
        )}

        <div className="flex min-w-0 flex-1 flex-col items-center gap-2.5">
          <span className="text-[15px] font-semibold" dir="ltr" style={{ color: p.mutedText }}>
            {chapter.chapter_number} / {novel.chapter_count ?? "?"}
          </span>
          <span className="h-px w-full" style={{ backgroundColor: p.divider }} />
        </div>

        {nextNumber !== null ? (
          <Link
            href={`/novel/${novel.id}/chapter/${nextNumber}`}
            // تحميل مسبق كامل للفصل التالي أول ما يقرب الزر — فيفتح فورًا
            prefetch
            aria-label="التالي"
            className="shrink-0"
            style={{ color: p.mutedText }}
          >
            <IconArrowRight />
          </Link>
        ) : (
          <span aria-hidden="true" className="shrink-0" style={{ color: p.mutedText, opacity: 0.35 }}>
            <IconArrowRight />
          </span>
        )}
      </div>

      {/* ستارة السطوع — تعتيم حقيقي فوق الشاشة حسب قيمة الشريط */}
      {mounted && brightness < 100 && (
        <div
          aria-hidden="true"
          className="pointer-events-none fixed inset-0 z-30 bg-black"
          style={{ opacity: 0.55 * Math.pow((100 - brightness) / 100, 1.6) }}
        />
      )}

      {showSheet && (
        <MobileReaderSettingsSheet
          theme={theme}
          setTheme={setTheme}
          fontIdx={wantLevel}
          setFontIdx={setFontLevel}
          fontSizes={FONT_LEVELS}
          brightness={brightness}
          setBrightness={setBrightness}
          onClose={() => setShowSheet(false)}
          onCustomize={() => setShowSheet(false)}
        />
      )}
    </div>
  );
}

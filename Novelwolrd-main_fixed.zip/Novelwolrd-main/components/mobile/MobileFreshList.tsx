import { getNovels } from "@/lib/novels";
import NovelListItem from "./NovelListItem";

export default async function MobileFreshList() {
  const all = await getNovels();
  const fresh = all.filter((n) => n.status !== "completed").slice(0, 3);

  if (fresh.length === 0) return null;

  

  return (
    <section className="mobile-reference-card nw-section">
      <div className="mobile-reference-section-heading">
        <span className="mobile-reference-heading-group">
          <h2>روايات جديدة</h2>
          <span className="mobile-reference-badge-pill">روايات جديدة على مدار 24 ساعة</span>
        </span>
        <a href="/categories" className="mobile-reference-more-link">المزيد ‹</a>
      </div>
      <ul className="nw-list">
        {fresh.map((novel) => (
          <li key={novel.id}>
            <NovelListItem novel={novel} wordCount={novel.word_count} countPlacement="chips-start" />
          </li>
        ))}
      </ul>
    </section>
  );
}

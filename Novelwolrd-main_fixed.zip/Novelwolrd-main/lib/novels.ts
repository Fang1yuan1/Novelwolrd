import * as React from "react";
import { supabase } from "./supabase";

// تخزين مؤقت لنتيجة الدالة طول الطلب الواحد فقط (React cache): لو أكتر من مكون بالصفحة طلب نفس البيانات
// (مثلًا كل الروايات) بتتجلب مرة واحدة بدل ما تتكرر. بنمر عبر متغير عشان ما ينكسر بناء نسخة المتصفح
// (ولو الدالة مش موجودة بتشتغل الدالة زي ما هي من غير تخزين).
const requestCache: <A extends unknown[], R>(
  fn: (...args: A) => R
) => (...args: A) => R =
  (React as unknown as { cache?: <F>(fn: F) => F }).cache ?? ((fn) => fn);

export type Novel = {
  id: number;
  created_at: string;
  title: string;
  description: string | null;
  cover_url: string | null;
  category: string | null;
  // حقول اختيارية — لو أضفتها لجدول novels في Supabase هتظهر تلقائيًا،
  // ولو مش موجودة الواجهة بتتعامل معاها بأمان (تخفي القسم أو تعرض بديل).
  author?: string | null;
  status?: "ongoing" | "completed" | string | null;
  tags?: string | null; // نص مفصول بفواصل، مثال: "VIP,روايات خفيفة,خيال أصلي"
  // أعداد محسوبة ومخزّنة تلقائيًا بقاعدة البيانات (تريجر) بدل حسابها من كل الفصول في كل صفحة — أسرع بكتير
  chapter_count?: number;
  word_count?: number;
};

export type Chapter = {
  id: number;
  created_at: string;
  novel_id: number;
  chapter_number: number;
  title: string | null;
  content: string;
  volume: string | null;
};

// نسخة خفيفة من الفصل (بدون النص الكامل) — كفاية لكل صفحات القوائم والتفاصيل
export type ChapterSummary = Pick<
  Chapter,
  "id" | "created_at" | "novel_id" | "chapter_number" | "title" | "volume"
>;

// ملخّص الفصل + عدد أحرفه — لصفحة الفهرس
export type ChapterListItem = ChapterSummary & {
  // عدد أحرف الفصل (0 = غير معروف، لو عمود word_count لسه ما اتضافش بقاعدة البيانات)
  word_count: number;
};

export type LatestUpdate = {
  chapter_id: number;
  chapter_number: number;
  chapter_title: string | null;
  created_at: string;
  novel_id: number;
  novel_title: string;
  novel_category: string | null;
};

// كل الروايات، الأحدث أولًا
const fetchNovels = requestCache(async (limit?: number): Promise<Novel[]> => {
  if (!supabase) return [];
  let query = supabase
    .from("novels")
    .select("*")
    .order("created_at", { ascending: false });
  if (limit) query = query.limit(limit);
  const { data, error } = await query;
  if (error || !data) return [];
  return data as Novel[];
});

// كل مستدعٍ بياخد نسخة مصفوفة خاصة به (فأي ترتيب/فلترة عنده ما تأثر على غيره بنفس الطلب)
export async function getNovels(limit?: number): Promise<Novel[]> {
  return [...(await fetchNovels(limit))];
}

// رواية واحدة بالتفصيل
export const getNovelById = requestCache(
  async (id: number | string): Promise<Novel | null> => {
    if (!supabase) return null;
    const { data, error } = await supabase
      .from("novels")
      .select("*")
      .eq("id", id)
      .single();
    if (error || !data) return null;
    return data as Novel;
  }
);

// كل فصول رواية معيّنة، مرتبة برقم الفصل
// كل فصول رواية معيّنة — بيجيبهم على دفعات (Supabase بيحدد حد أقصى ~1000 صف بالطلب
// الواحد افتراضيًا)، عشان الروايات اللي عندها أكتر من 1000 فصل متتقصش عند آخر فصل ظاهر
export async function getChaptersByNovel(novelId: number | string): Promise<Chapter[]> {
  if (!supabase) return [];
  const pageSize = 1000;
  let from = 0;
  const all: Chapter[] = [];
  while (true) {
    const { data, error } = await supabase
      .from("chapters")
      .select("*")
      .eq("novel_id", novelId)
      .order("chapter_number", { ascending: true })
      .range(from, from + pageSize - 1);
    if (error || !data) break;
    all.push(...(data as Chapter[]));
    if (data.length < pageSize) break;
    from += pageSize;
  }
  return all;
}

// جلب كل صفوف الفصول بأعمدة محددة (Supabase بيحدد ~1000 صف بالطلب): الدفعة الأولى بتجيب معاها العدد الكلي،
// وباقي الدفعات بتتجلب مع بعض في نفس الوقت (مو واحدة ورا الثانية).
// بيرجّع null لو أي طلب فشل (مثلًا عمود مش موجود) عشان المستدعي يجرّب بديل.
async function fetchAllChapterRows(
  novelId: number | string,
  columns: string
): Promise<Record<string, unknown>[] | null> {
  if (!supabase) return null;
  const pageSize = 1000;
  const page = (from: number) =>
    supabase!
      .from("chapters")
      .select(columns, { count: "exact" })
      .eq("novel_id", novelId)
      .order("chapter_number", { ascending: true })
      .range(from, from + pageSize - 1);

  const first = await page(0);
  if (first.error || !first.data) return null;
  const rows = first.data as unknown as Record<string, unknown>[];
  const total = first.count ?? rows.length;
  if (rows.length < pageSize || total <= pageSize) return rows;

  const rest = await Promise.all(
    Array.from({ length: Math.ceil(total / pageSize) - 1 }, (_, i) =>
      page((i + 1) * pageSize)
    )
  );
  const all = [...rows];
  for (const r of rest) {
    if (r.error || !r.data) return null;
    all.push(...(r.data as unknown as Record<string, unknown>[]));
  }
  return all;
}

// أعمدة اختيارية (volume / word_count) ممكن ما تكونش موجودة بقاعدة البيانات.
// بنجرّب الأعمدة من الأكمل للأبسط، وبنتذكّر التركيبة اللي اشتغلت (5 دقايق) عشان الطلبات الجاية تنجح من أول مرة
// من غير محاولات فاشلة، ولو أضفت العمود بعدين بيتلقّطه الموقع تلقائيًا بعد دقايق.
const COLUMNS_TTL_MS = 5 * 60 * 1000;
const workingColumns = new Map<string, { cols: string; at: number }>();

async function fetchChapterRowsAdaptive(
  novelId: number | string,
  key: string,
  candidates: string[]
): Promise<Record<string, unknown>[] | null> {
  const cached = workingColumns.get(key);
  const fresh = cached && Date.now() - cached.at < COLUMNS_TTL_MS;
  const order = fresh
    ? [cached.cols, ...candidates.filter((c) => c !== cached.cols)]
    : candidates;
  for (const cols of order) {
    const rows = await fetchAllChapterRows(novelId, cols);
    if (rows) {
      if (!fresh || cached?.cols !== cols) {
        workingColumns.set(key, { cols, at: Date.now() });
      }
      return rows;
    }
  }
  return null;
}

const CHAPTER_BASE_COLUMNS = "id, novel_id, chapter_number, title, created_at";

// كل فصول الرواية بدون نصها (id, رقم, عنوان, تاريخ, مجلد) — للقوائم وصفحة التفاصيل.
// أخف بمراحل من getChaptersByNovel اللي بتسحب نص كل فصل.
export async function getChapterSummaries(
  novelId: number | string
): Promise<ChapterSummary[]> {
  const rows = await fetchChapterRowsAdaptive(novelId, "summaries", [
    `${CHAPTER_BASE_COLUMNS}, volume`,
    CHAPTER_BASE_COLUMNS,
  ]);
  if (!rows) return [];
  return rows.map((r) => ({
    ...(r as unknown as ChapterSummary),
    volume: (r.volume as string | null | undefined) ?? null,
  }));
}

// معاينة الفصول لصفحة تفاصيل الرواية: أول فصل + آخر N فصل + العدد الكلي — بطلبين خفيفين مع بعض،
// مهما كان عدد الفصول (بدل سحب كل القائمة لمجرد عرض آخر ٣ فصول). القائمة الكاملة بصفحة الفهرس.
export type ChapterPreview = {
  total: number;
  first: ChapterSummary | null;
  recent: ChapterSummary[]; // آخر N فصل بترتيب تصاعدي
};

export async function getChapterPreview(
  novelId: number | string,
  recentCount = 30
): Promise<ChapterPreview> {
  const empty: ChapterPreview = { total: 0, first: null, recent: [] };
  if (!supabase) return empty;

  const cached = workingColumns.get("preview");
  const fresh = cached && Date.now() - cached.at < COLUMNS_TTL_MS;
  const candidates = [`${CHAPTER_BASE_COLUMNS}, volume`, CHAPTER_BASE_COLUMNS];
  const order = fresh
    ? [cached.cols, ...candidates.filter((c) => c !== cached.cols)]
    : candidates;

  for (const cols of order) {
    const [firstRes, lastRes] = await Promise.all([
      supabase
        .from("chapters")
        .select(cols)
        .eq("novel_id", novelId)
        .order("chapter_number", { ascending: true })
        .limit(1),
      supabase
        .from("chapters")
        .select(cols, { count: "exact" })
        .eq("novel_id", novelId)
        .order("chapter_number", { ascending: false })
        .limit(recentCount),
    ]);
    if (firstRes.error || lastRes.error || !firstRes.data || !lastRes.data) {
      continue;
    }
    workingColumns.set("preview", { cols, at: Date.now() });
    const norm = (r: unknown): ChapterSummary => ({
      ...(r as ChapterSummary),
      volume: (r as { volume?: string | null }).volume ?? null,
    });
    const recentDesc = (lastRes.data as unknown[]).map(norm);
    return {
      total: lastRes.count ?? recentDesc.length,
      first: firstRes.data[0] ? norm(firstRes.data[0]) : null,
      recent: recentDesc.reverse(),
    };
  }
  return empty;
}

// قائمة الفصول لصفحة الفهرس: ملخّص كل فصل + عدد أحرفه، من غير جلب النص أبدًا.
// عدد الأحرف بيجي من عمود chapters.word_count (supabase_add_chapter_word_count.sql)؛
// لو العمود لسه مش موجود بيرجع 0 والواجهة بتخفي العدد بدل ما تسحب نص كل الفصول وتبطّئ الصفحة.
export async function getChapterListItems(
  novelId: number | string
): Promise<ChapterListItem[]> {
  const rows = await fetchChapterRowsAdaptive(novelId, "toc", [
    `${CHAPTER_BASE_COLUMNS}, volume, word_count`,
    `${CHAPTER_BASE_COLUMNS}, word_count`,
    `${CHAPTER_BASE_COLUMNS}, volume`,
    CHAPTER_BASE_COLUMNS,
  ]);
  if (!rows) return [];
  return rows.map((r) => ({
    ...(r as unknown as ChapterSummary),
    volume: (r.volume as string | null | undefined) ?? null,
    word_count: Number(r.word_count) || 0,
  }));
}

// فصل واحد برقمه
export async function getChapterByNumber(
  novelId: number | string,
  chapterNumber: number | string
): Promise<Chapter | null> {
  if (!supabase) return null;
  const { data, error } = await supabase
    .from("chapters")
    .select("*")
    .eq("novel_id", novelId)
    .eq("chapter_number", chapterNumber)
    .single();
  if (error || !data) return null;
  return data as Chapter;
}

// رقم الفصل السابق/التالي الفعليين (أقرب رقم موجود فعلاً بقاعدة البيانات، مو current±1) —
// ضروري لما تكون بعض الفصول مرقّمة بكسر (644.5) بسبب تعارض ترقيم أثناء الاستيراد؛
// current±1 كان يتخطّاها لأنها مش تطابق حسابيًا.
export async function getAdjacentChapterNumbers(
  novelId: number | string,
  currentNumber: number
): Promise<{ prev: number | null; next: number | null }> {
  if (!supabase) return { prev: null, next: null };
  const [prevRes, nextRes] = await Promise.all([
    supabase
      .from("chapters")
      .select("chapter_number")
      .eq("novel_id", novelId)
      .lt("chapter_number", currentNumber)
      .order("chapter_number", { ascending: false })
      .limit(1),
    supabase
      .from("chapters")
      .select("chapter_number")
      .eq("novel_id", novelId)
      .gt("chapter_number", currentNumber)
      .order("chapter_number", { ascending: true })
      .limit(1),
  ]);
  const prev = (prevRes.data?.[0] as { chapter_number?: number } | undefined)?.chapter_number ?? null;
  const next = (nextRes.data?.[0] as { chapter_number?: number } | undefined)?.chapter_number ?? null;
  return { prev, next };
}

// تجميع الفصول حسب الجزء/المجلد (volume)
export function groupChaptersByVolume<T extends { volume: string | null }>(
  chapters: T[]
): { volume: string; chapters: T[] }[] {
  const groups = new Map<string, T[]>();
  const noVolumeKey = "الفصول";
  for (const ch of chapters) {
    const key = ch.volume?.trim() || noVolumeKey;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key)!.push(ch);
  }
  return Array.from(groups.entries()).map(([volume, chapters]) => ({
    volume,
    chapters,
  }));
}

// عدد الفصول لرواية معيّنة (بدون سحب المحتوى الكامل)
export async function getChapterCount(novelId: number | string): Promise<number> {
  if (!supabase) return 0;
  const { count, error } = await supabase
    .from("chapters")
    .select("id", { count: "exact", head: true })
    .eq("novel_id", novelId);
  if (error || count == null) return 0;
  return count;
}

// ترتيب رواية بين كل الروايات حسب عدد الفصول (مقياس حقيقي بديل عن أي "ترتيب" وهمي)
// بنستخدم العمود المخزّن novels.chapter_count (طلب واحد خفيف) بدل عدّ فصول كل رواية بطلب مستقل.
export async function getNovelRank(
  novelId: number | string
): Promise<{ rank: number; total: number } | null> {
  if (!supabase) return null;

  const { data, error } = await supabase
    .from("novels")
    .select("id, chapter_count")
    .order("created_at", { ascending: false });

  let withCounts: { id: number; count: number }[];
  if (!error && data && data.length > 0) {
    withCounts = (data as { id: number; chapter_count: number | null }[]).map(
      (n) => ({ id: n.id, count: n.chapter_count ?? 0 })
    );
  } else {
    // احتياطي لو العمود chapter_count مش موجود: الطريقة القديمة (أبطأ)
    const novels = await getNovels();
    if (novels.length === 0) return null;
    const counts = await Promise.all(novels.map((n) => getChapterCount(n.id)));
    withCounts = novels.map((n, i) => ({ id: n.id, count: counts[i] }));
  }

  withCounts.sort((a, b) => b.count - a.count);
  const idx = withCounts.findIndex((n) => String(n.id) === String(novelId));
  if (idx === -1) return null;
  return { rank: idx + 1, total: withCounts.length };
}

// آخر الفصول المضافة عبر كل الروايات (لقسم "آخر التحديثات")
export async function getLatestUpdates(limit = 20): Promise<LatestUpdate[]> {
  if (!supabase) return [];
  const { data, error } = await supabase
    .from("chapters")
    .select("id, chapter_number, title, created_at, novel_id, novels(id, title, category)")
    .order("created_at", { ascending: false })
    .limit(limit);
  if (error || !data) return [];
  return (data as any[])
    .filter((row) => row.novels)
    .map((row) => ({
      chapter_id: row.id,
      chapter_number: row.chapter_number,
      chapter_title: row.title,
      created_at: row.created_at,
      novel_id: row.novels.id,
      novel_title: row.novels.title,
      novel_category: row.novels.category,
    }));
}

// تقسيم حقل التصنيف (قد يحتوي أكتر من تصنيف مفصول بفواصل) لمصفوفة نظيفة
export function parseCategories(category: string | null | undefined): string[] {
  if (!category) return [];
  return category
    .split(",")
    .map((c) => c.trim())
    .filter(Boolean);
}

// دمج مصفوفة تصنيفات في نص واحد مفصول بفواصل، جاهز للحفظ في Supabase
export function joinCategories(categories: string[]): string {
  return categories.map((c) => c.trim()).filter(Boolean).join(",");
}

// التصنيفات الموجودة فعليًا مع عدد الروايات بكل تصنيف (مبني على جدول novels)
// كل رواية ممكن يكون ليها أكتر من تصنيف — كل تصنيف بيتحسب على حدة
export async function getCategoriesWithCounts(): Promise<
  { category: string; count: number }[]
> {
  return countCategories(await getNovels());
}

// نفس الحساب على قائمة روايات محمّلة أصلًا (بدون جلبها مرة ثانية)
export function countCategories(
  novels: Novel[]
): { category: string; count: number }[] {
  const map = new Map<string, number>();
  for (const n of novels) {
    for (const cat of parseCategories(n.category)) {
      map.set(cat, (map.get(cat) || 0) + 1);
    }
  }
  return Array.from(map.entries()).map(([category, count]) => ({
    category,
    count,
  }));
}

// كل الروايات اللي تحت تصنيف معيّن (اسم التصنيف بالضبط) — لصفحة التصنيف الحقيقية
export async function getNovelsByCategory(categoryName: string): Promise<Novel[]> {
  const all = await getNovels();
  return all.filter((n) => parseCategories(n.category).includes(categoryName));
}

// كل روايات مؤلف معيّن (بفلتر بقاعدة البيانات بدل جلب كل الروايات وفلترتها بالكود)
export async function getNovelsByAuthor(author: string): Promise<Novel[]> {
  if (!supabase || !author) return [];
  const { data, error } = await supabase
    .from("novels")
    .select("*")
    .eq("author", author)
    .order("created_at", { ascending: false });
  if (error || !data) return [];
  return data as Novel[];
}

// روايات مشابهة (بينها تصنيف مشترك واحد على الأقل) لعرضها في صفحة التفاصيل
export async function getRelatedNovels(
  category: string | null,
  excludeId: number | string,
  limit = 6
): Promise<Novel[]> {
  if (!supabase || !category) return [];
  const wanted = new Set(parseCategories(category));
  if (wanted.size === 0) return [];

  // التصنيفات نص حر مفصول بفواصل، فبنقلّل المرشّحين بالقاعدة بـilike ثم نتأكد بالتطابق التام بالكود.
  // أسماء التصنيفات اللي فيها رموز خاصة بصيغة الفلتر بنتخطاها (وبتتغطى بالاحتياطي تحت لو ما لقينا كفاية).
  const safe = [...wanted].filter((c) => !/[,()%_*\\"]/.test(c));
  let candidates: Novel[] | null = null;
  if (safe.length === wanted.size) {
    const orFilter = safe.map((c) => `category.ilike.%${c}%`).join(",");
    const { data, error } = await supabase
      .from("novels")
      .select("*")
      .or(orFilter)
      .neq("id", Number(excludeId))
      .order("created_at", { ascending: false })
      .limit(60);
    if (!error && data) candidates = data as Novel[];
  }
  if (!candidates) {
    candidates = (await getNovels()).filter((n) => n.id !== Number(excludeId));
  }

  return candidates
    .filter((n) => n.id !== Number(excludeId))
    .filter((n) => parseCategories(n.category).some((c) => wanted.has(c)))
    .slice(0, limit);
}

// إجمالي عدد الأحرف عبر كل فصول الرواية — تقدير حقيقي لعدد الكلمات (بدل رقم وهمي)
export function getWordCount(chapters: Chapter[]): number {
  return chapters.reduce((sum, ch) => sum + (ch.content?.length || 0), 0);
}

// تنسيق عدد كبير بصيغة مختصرة (مثال: 134582 → "134.6 ألف")
export function formatCount(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(2)} مليون`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)} ألف`;
  return `${n}`;
}

// تنسيق وقت نسبي بسيط (اليوم، أمس، أو تاريخ)
export function formatRelativeTime(iso: string): string {
  const date = new Date(iso);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  if (diffMin < 1) return "الآن";
  if (diffMin < 60) return `منذ ${diffMin} د`;
  const diffHour = Math.floor(diffMin / 60);
  if (diffHour < 24) return `منذ ${diffHour} س`;
  const diffDay = Math.floor(diffHour / 24);
  if (diffDay < 7) return `منذ ${diffDay} يوم`;
  return date.toLocaleDateString("ar", { day: "numeric", month: "short", year: "numeric" });
}

// تاريخ ووقت كامل بصيغة رقمية ثابتة (مثال: 2026-08-20 13:56:01) — كالمرجع الصيني
export function formatFullDateTime(iso: string): string {
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  const date = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const time = `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  return `${date} ${time}`;
}

// ختم وقت الفصل بصفحة الفهرس — زي المرجع (شهر ويوم + ساعة): «20 سبتمبر 00:06»،
// ولو من سنة غير الحالية: «13 يوليو 2025 06:56».
// بتوقيت UTC صراحةً عشان يطلع نفس النص بالسيرفر وبالمتصفح (من غير اختلاف هيدريشن بين المناطق الزمنية)
const ARABIC_MONTHS = [
  "يناير",
  "فبراير",
  "مارس",
  "أبريل",
  "مايو",
  "يونيو",
  "يوليو",
  "أغسطس",
  "سبتمبر",
  "أكتوبر",
  "نوفمبر",
  "ديسمبر",
];

export function formatChapterStamp(iso: string): string {
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  const year =
    d.getUTCFullYear() === new Date().getUTCFullYear()
      ? ""
      : ` ${d.getUTCFullYear()}`;
  return `${d.getUTCDate()} ${ARABIC_MONTHS[d.getUTCMonth()]}${year} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`;
}
